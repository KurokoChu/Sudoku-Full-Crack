# Sudoku-Full-Crack
* Computer Programming “COMPRO” @ KMITL
* Sudoku is a 9x9 grid number puzzle with 3x3 9-sub grid. Game start with a few of digits 1 - 9 in 9x9 grid,
requires player to fill blanks in a 9x9 grid with digits. each column, each row, and each of the nine 3×3 subgrids must contains all of the digits from 1 to 9.

## Dataset
* [1M Games Sudoku](https://www.kaggle.com/bryanpark/sudoku)

## Author
* 60070099 : Supakit Rodthong

---

Faculty of Information Technology

King Mongkut's Institute of Technology Ladkrabang
